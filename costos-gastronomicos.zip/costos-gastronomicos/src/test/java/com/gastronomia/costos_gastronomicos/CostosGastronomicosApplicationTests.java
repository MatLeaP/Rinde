package com.gastronomia.costos_gastronomicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CostosGastronomicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
